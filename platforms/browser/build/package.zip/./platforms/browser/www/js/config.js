var krms_config ={			
	'ApiUrl' : "http://fellybellyapp.com/merchantapp/api",	
	'DialogDefaultTitle' : "FellyBelly Manager",
	'pushNotificationSenderid' : "629248534750",
	'APIHasKey' : "fed7b441b349bae8f146711fbd215e90"
};